CROSSFADE - INFO 579 Project 1 sample data (info579_group_1)

data.xlsx        the sample data exactly as handed in for Project 1
csv/<table>.csv  the same data, one file per table, exported by tools/export_p1_data.py

CSV conventions
  header row     the column names used in data.xlsx
  empty field    NULL
  dates          yyyy-mm-dd
  timestamps     yyyy-mm-dd hh:mm:ss (Play.Played At)
  decimals       exact stored value, no rounding

Tables and rows
  artist                 8
  track                 15
  genre                 10
  listener               8
  scoring_model          5
  station                8
  track_score           27
  genre_probability    270
  station_blend         19
  play                  31
