/* 
	Exercise 1:
    Write a query to display the unique first names of trainers.
    Sort the results.
*/
SELECT DISTINCT first_name FROM trainer ORDER BY first_name;


/*
	Exercise 2:
    Write a query to display the first name, last name and
    hire date of the employees that were hired after January 11, 2011. 
    Sort the results according to when they were hired.  
*/
SELECT first_name, last_name, hire_date FROM employee
	WHERE hire_date > '2011-01-11' ORDER BY hire_date;


/*
	Exercise 3:
    Write a query to display the first name, last name and
    hire date of employees  hired between January 11, 2005 
    and January 11, 2011. 
    Sort the results according to when they were hired. 
*/
SELECT first_name, last_name, hire_date FROM employee
	WHERE hire_date BETWEEN '2005-01-11' AND '2011-01-11' ORDER BY hire_date;


/*
	Exercise 4:
    Write a query to display the first name, last name 
    and department id for all employees whose phone begins
    with '(212)'.
    Sort the output by department id and last name.
*/
SELECT first_name, last_name, department_code FROM employee
	WHERE phone_number LIKE '(212)%' ORDER BY department_code, last_name;


/*
	Exercise 5:
    Write a query to display the equipment id, equipment name, 
    and equipment cost increased by 15% expressed as a whole number
    for all items with a cost higher than 100 dollars.
    Sort the results by the equipment id.
*/
SELECT equipment_id, name, ROUND(cost * 1.15) FROM equipment
	WHERE cost > 100 ORDER BY equipment_id;


/*
	Exercise 6:
    Write a query to display the first name, last name, hire date 
    and year on which the employee was hired.
    Sort the results by the year and last name.
*/
SELECT first_name, last_name, hire_date, EXTRACT(YEAR FROM hire_date) FROM employee
	ORDER BY EXTRACT(YEAR FROM hire_date), last_name;



/*
	Exercise 7:
    Write a query to display the first name, last name
    and hire date for all employees. 
    Sort the data by hire date in descending order and
    last name in ascending order.
*/
SELECT first_name, last_name, hire_date FROM employee
	ORDER BY hire_date DESC, last_name ASC;


/*
	Exercise 8:
    Write a query to display all columns
    for the employee who joined the company first.
    Do not hard-code any filter. 
*/
SELECT * FROM employee ORDER BY hire_date LIMIT 1;


/*
	Exercise 9:
    Write a query to display the department code and
    the minimum and maximum hire dates for each department
    with a name.
*/
SELECT department_code, MIN(hire_date), MAX(hire_date) FROM employee
	WHERE department_code IS NOT NULL GROUP BY department_code;


/*
	Exercise 10:
    Write a query to display the training id
    and number of trainers for each training course
	with more than one trainer.
*/
SELECT training_id, COUNT(*) FROM trainer
	GROUP BY training_id HAVING COUNT(*) > 1;
