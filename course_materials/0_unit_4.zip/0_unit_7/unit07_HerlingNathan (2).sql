/*
	Exercise 1:
    Write a query to display the complete list of trainings (name)
    and trainers (first and last name as separate columns)
    available for each training.
    Sort the output by training name and trainers' last name.
*/
SELECT T.name, TR.first_name, TR.last_name
FROM training AS T LEFT OUTER JOIN trainer AS TR
ON T.training_id = TR.training_id
ORDER BY T.name, TR.last_name;


/*
	Exercise 2:
    Write a query to display the concatenation of the
    trainer first name and their training names separated
    by ': ' (e.g. 'John: Intro to Python')
    for trainers that did not provide their last name.
*/
SELECT CONCAT(TR.first_name, ': ', T.name)
FROM trainer AS TR INNER JOIN training AS T
ON TR.training_id = T.training_id
WHERE TR.last_name IS NULL;


/*
	Exercise 3:
    Write a query to display the employee code, first name, last name,
    equipment name, and equipment cost for all of the employees.
    Sort the results by employee code.
*/
SELECT E.employee_code, E.first_name, E.last_name, Q.name, Q.cost FROM employee AS E
LEFT OUTER JOIN employee_equipment AS EQ ON E.employee_code = EQ.employee_code
LEFT OUTER JOIN equipment AS Q ON EQ.equipment_id = Q.equipment_id
ORDER BY E.employee_code;


/*
	Exercise 4:
    Write a query to display the first name, last name
    and training name for the employee 'Tom Harper'.
    Sort the results by training name in descending order.
*/
SELECT E.first_name, E.last_name, T.name FROM employee AS E
INNER JOIN employee_training AS ET ON E.employee_code = ET.employee_code
INNER JOIN training AS T ON ET.training_id = T.training_id
WHERE E.first_name = 'Tom' AND E.last_name = 'Harper'
ORDER BY T.name DESC;


/*
	Exercise 5:
    Write a query to display the distinct list of equipment names
    used by the current employees.
    Sort the output by equipment name.
*/
SELECT DISTINCT Q.name FROM equipment AS Q
INNER JOIN employee_equipment AS EQ ON Q.equipment_id = EQ.equipment_id
INNER JOIN employee AS E ON EQ.employee_code = E.employee_code
ORDER BY Q.name;


/*
	Exercise 6:
    Write a query to display the employee code, first name, last name,
    training id and training name for employees of the following departments:
    'Sales and Marketing', 'Accounting and Finance' and 'Production'.
*/
SELECT E.employee_code, E.first_name, E.last_name, T.training_id, T.name FROM employee AS E
INNER JOIN department AS D ON E.department_code = D.department_code
INNER JOIN employee_training AS ET ON E.employee_code = ET.employee_code
INNER JOIN training AS T ON ET.training_id = T.training_id
WHERE D.name IN ('Sales and Marketing', 'Accounting and Finance', 'Production');


/*
	Exercise 7:
    Write a query to display the employee code, first name, last name,
    department code and department name for all employess using 'Headsets'
    including those with no assigned department.
*/
SELECT E.employee_code, E.first_name, E.last_name, D.department_code, D.name FROM employee AS E
INNER JOIN employee_equipment AS EQ ON E.employee_code = EQ.employee_code
INNER JOIN equipment AS Q ON EQ.equipment_id = Q.equipment_id
LEFT OUTER JOIN department AS D ON E.department_code = D.department_code
WHERE Q.name = 'Headsets';


/*
	Exercise 8:
    Write a query to display the employee first name, last name and the
    number and total cost of equipment items used by each employee,
    including those not using any equipment.
*/
SELECT E.first_name, E.last_name, COUNT(Q.equipment_id), SUM(Q.cost) FROM employee AS E
LEFT OUTER JOIN employee_equipment AS EQ ON E.employee_code = EQ.employee_code
LEFT OUTER JOIN equipment AS Q ON EQ.equipment_id = Q.equipment_id
GROUP BY E.employee_code, E.first_name, E.last_name;


/*
	Exercise 9:
    Write a query to display the first name and last name of employees
    that do not use any equipment and do not belong to any department.
*/
SELECT E.first_name, E.last_name FROM employee AS E
LEFT OUTER JOIN employee_equipment AS EQ ON E.employee_code = EQ.employee_code
LEFT OUTER JOIN department AS D ON E.department_code = D.department_code
WHERE EQ.employee_code IS NULL AND D.department_code IS NULL;


/*
	Exercise 10:
    Get the cartesian product of employees and trainings
    showing the employee's first name and last name, and the
    training name.
    Sort the results by employee last name in ascending order
    and training name in descending order.
*/
SELECT E.first_name, E.last_name, T.name
FROM employee AS E CROSS JOIN training AS T
ORDER BY E.last_name ASC, T.name DESC;


