/*
	Exercise 1:
    Write a query to list all the first name
    and last name of all employees and trainers.
*/
SELECT first_name, last_name FROM employee
UNION ALL
SELECT first_name, last_name FROM trainer;



/*
	Exercise 2:
	Write a query to list all the last names
    of employess not belonging to any department
    that are not last names of trainers.
*/
SELECT last_name FROM employee WHERE department_code IS NULL
EXCEPT
SELECT last_name FROM trainer;



/*
	Exercise 3:
	Write a query to list all the last names
    of employess from the 'Customer Service'
    department that are also last names of trainers.
*/
SELECT last_name FROM employee WHERE department_code =
(SELECT department_code FROM department WHERE name = 'Customer Service')
INTERSECT
SELECT last_name FROM trainer;



/*
	Exercise 4:
	Using subqueires, get the employee code, first name
    and last name of those employees whose last name
    matches the last name of a trainer.
*/
SELECT employee_code, first_name, last_name FROM employee
WHERE last_name =
ANY (SELECT last_name FROM trainer);



/*
	Exercise 5:
	Using subqueires, get the employee code, first name
    and last name of those employees whose last name
    does not match the last name of any other employee.
*/
SELECT E1.employee_code, E1.first_name, E1.last_name FROM employee AS E1
WHERE NOT EXISTS
(SELECT * FROM employee AS E2
WHERE E1.last_name = E2.last_name AND E1.employee_code != E2.employee_code);



/*
	Exercise 6:
	Using subqueires, get the employee code, first name
    and last name of those employees that participate in 
    a training with a least another employee.
*/
SELECT employee_code, first_name, last_name FROM employee WHERE employee_code IN
(SELECT T1.employee_code FROM employee_training AS T1
WHERE EXISTS
(SELECT * FROM employee_training AS T2
WHERE T1.training_id = T2.training_id AND T1.employee_code != T2.employee_code));



/*
	Exercise 7:
	Using subqueires, get the employee code, first name
    and last name of those employees that where hired at least
    365 days after any other employee.
*/
SELECT employee_code, first_name, last_name FROM employee
WHERE hire_date >=
ANY (SELECT DATE_ADD(hire_date, INTERVAL 365 DAY) FROM employee);



/*
	Exercise 8:
    Write a query to display the first name,
    last name and phone number of all the employees.
    If the employee does not have a phone number
    print 'Unknown Number' instead.
*/
SELECT first_name, last_name,
IFNULL(phone_number, 'Unknown Number') AS phone_number
FROM employee;



/*
	Exercise 9:
    Write a query to display the first name,
    last name and column named 'category' that will
    contain the value "Senior" if the employee was hired
    before 2010 and "Junior" otherwise.
*/
SELECT first_name, last_name,
IF(hire_date < '2010-01-01', 'Senior', 'Junior') AS category
FROM employee;



/*
	Exercise 10:
	Get how many equipment items belong to 
    'Tier 1', 'Tier 2', and 'Tier 3' where
    'Tier 1' corresponds to equipment with cost >= 1000,
    'Tier 2' corresponds to equipment with 1000 > cost >= 100
    and 'Tier 3' corresponds to equipment with cost < 100.
*/
SELECT tbl.tier, COUNT(*) AS num_equipment FROM
(SELECT
CASE
WHEN cost >= 1000 THEN 'Tier 1'
WHEN cost >= 100 THEN 'Tier 2'
ELSE 'Tier 3'
END AS tier FROM equipment) AS tbl
GROUP BY tbl.tier;


