/*
	Exercise 1:
	Grant the required privileges to user dummy_user
    so that the user can run procedures on the
    database business.
*/
GRANT EXECUTE ON business.* TO dummy_user;



/*
	Exercise 2:
    User dummy_user can run all procederues on the
    database business. Make the user unable to
    run procedure new_training.
*/
-- MySQL privileges are additive: a routine-level REVOKE cannot carve one
-- procedure out of a database-level EXECUTE grant (it fails with ERROR 1403).
-- So the database-level EXECUTE is revoked and EXECUTE is re-granted on every
-- routine in business except procedure new_training.
REVOKE EXECUTE ON business.* FROM dummy_user;

DELIMITER //
CREATE PROCEDURE business.tmp_grant_execute_except_new_training()
BEGIN
	DECLARE done TINYINT(1) DEFAULT FALSE;
	DECLARE r_type VARCHAR(20);
	DECLARE r_name VARCHAR(64);
	DECLARE cur CURSOR FOR
		SELECT ROUTINE_TYPE, ROUTINE_NAME FROM information_schema.ROUTINES
		WHERE ROUTINE_SCHEMA = 'business'
		AND NOT (ROUTINE_TYPE = 'PROCEDURE' AND ROUTINE_NAME = 'new_training')
		AND ROUTINE_NAME != 'tmp_grant_execute_except_new_training';
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	OPEN cur;
	grant_loop: LOOP
		FETCH cur INTO r_type, r_name;
		IF done THEN
			LEAVE grant_loop;
		END IF;
		SET @grant_sql = CONCAT('GRANT EXECUTE ON ', r_type, ' business.`', r_name, '` TO dummy_user');
		PREPARE stmt FROM @grant_sql;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
	END LOOP;
	CLOSE cur;
END //
DELIMITER ;

CALL business.tmp_grant_execute_except_new_training();
DROP PROCEDURE business.tmp_grant_execute_except_new_training;



/*
	Exercise 3:
    User dummy_user can retrieve data from all tables
    in database business. Make the user unable to
    get data from table trainer.
*/
-- Same additive rule: REVOKE SELECT ON business.trainer fails (ERROR 1147)
-- while the database-level SELECT stays in force. Revoke it and re-grant
-- SELECT on every table except trainer. (IF EXISTS, MySQL 8.0.30+, keeps the
-- script running if the stated starting grant was never made.)
REVOKE IF EXISTS SELECT ON business.* FROM dummy_user;
GRANT SELECT ON business.department TO dummy_user;
GRANT SELECT ON business.employee TO dummy_user;
GRANT SELECT ON business.employee_equipment TO dummy_user;
GRANT SELECT ON business.employee_training TO dummy_user;
GRANT SELECT ON business.equipment TO dummy_user;
GRANT SELECT ON business.training TO dummy_user;



/*
	Exercise 4:
    Give user dummy_user give user all privileges
    required to manage the data on table equipment.
*/
-- Managing data = reading and changing rows (DML), not changing the structure.
GRANT SELECT, INSERT, UPDATE, DELETE ON business.equipment TO dummy_user;



/*
	Exercise 5:
    Allow user dummy_user to create new tables
    on database business.
*/
GRANT CREATE ON business.* TO dummy_user;



/*
	Exercise 6:
    User dummy_user has privielges to create
    any object on database business. Make the
    user unable to create views.
*/
REVOKE CREATE VIEW ON business.* FROM dummy_user;



/*
	Exercise 7:
    Allow user dummy_user to use triggers on
    table employee.
*/
GRANT TRIGGER ON business.employee TO dummy_user;



/*
	Exercise 8:
	User dummy_user has all privielges to manage
    the data on table training. Make the user only
    able to insert new rows.
*/
REVOKE SELECT, UPDATE, DELETE ON business.training FROM dummy_user;



/*
	Exercise 9:
	Allow user dummy_user to create or drop indexes
    on table training.
*/
GRANT INDEX ON business.training TO dummy_user;



/*
	Exercise 10:
	Give all privileges to user dummy_user to manage
    routines on database business when the user
    logins from host 121.111.456.987
*/
-- GRANT does not create accounts in MySQL 8, and dummy_user@'121.111.456.987'
-- is a different account from dummy_user@'%', so it must be created first.
CREATE USER IF NOT EXISTS dummy_user@'121.111.456.987' IDENTIFIED BY 'dummy_password';
GRANT CREATE ROUTINE, ALTER ROUTINE, EXECUTE ON business.* TO dummy_user@'121.111.456.987';
