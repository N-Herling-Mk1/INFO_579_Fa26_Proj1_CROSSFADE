DELIMITER $$
/*
	Exercise 1:
    Create a trigger check_name on the table department
    that activates after updating a department.
    If the name of the department has changed,
    the trigger must unlink every employee that
    belonged to such department.
*/
DROP TRIGGER IF EXISTS check_name$$
CREATE TRIGGER check_name
	AFTER UPDATE ON department FOR EACH ROW
BEGIN
	-- Binary comparison so a case-only rename (e.g. 'Production' -> 'PRODUCTION')
	-- also counts as a change; the column collation is case-insensitive.
	IF CAST(OLD.name AS BINARY) <> CAST(NEW.name AS BINARY) THEN
		UPDATE employee SET department_code = NULL
		WHERE department_code = OLD.department_code;
	END IF;
END$$


/*
	Exercise 2:
	Create a trigger named check_quota on the table
    employee_equipment that activates when new
    employee-equipment pairs are inserted.
    The trigger must check if the total equipment cost
    for the employee plus the new equipment is higher
    than 7000. In that case, instead of inserting the
    new pair, throw an exception with the message
    "Quota excededed by employee_code".
*/
DROP TRIGGER IF EXISTS check_quota$$
CREATE TRIGGER check_quota
	BEFORE INSERT ON employee_equipment FOR EACH ROW
BEGIN
	DECLARE current_cost DECIMAL(13,2);
	DECLARE new_cost DECIMAL(13,2);
	DECLARE error_message VARCHAR(128);

	-- Total cost of the equipment the employee already has.
	SET current_cost = (SELECT COALESCE(SUM(Q.cost), 0)
						FROM employee_equipment AS EQ INNER JOIN equipment AS Q
						ON EQ.equipment_id = Q.equipment_id
						WHERE EQ.employee_code = NEW.employee_code);

	-- Cost of the equipment being assigned.
	SET new_cost = (SELECT COALESCE(cost, 0) FROM equipment
					WHERE equipment_id = NEW.equipment_id);

	IF current_cost + COALESCE(new_cost, 0) > 7000 THEN
		SET error_message = CONCAT('Quota excededed by ', NEW.employee_code);
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
	END IF;
END$$


/*
	Exercise 3:
    Create a procedure named new_training that
    takes a new training id, new training name
    and an existing trainer code as arguments.
    The procedure must insert the training into
    the training table and assign the trainer to
    this new training. If the trainer was
    instructing a training with other trainers,
    those must be assigned to the new trianing too.
*/
DROP PROCEDURE IF EXISTS new_training$$
CREATE PROCEDURE new_training (
	IN new_training_id INT,
	IN new_training_name VARCHAR(50),
	IN input_trainer_code CHAR(5))
BEGIN
	DECLARE old_training_id INT;

	-- Training the trainer is currently instructing.
	SET old_training_id = (SELECT training_id FROM trainer
						   WHERE trainer_code = input_trainer_code);

	IF old_training_id IS NULL THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Trainer does not exist';
	END IF;

	INSERT INTO training (training_id, name)
	VALUES (new_training_id, new_training_name);

	-- Reassign the trainer and every co-trainer of the same training.
	UPDATE trainer SET training_id = new_training_id
	WHERE training_id = old_training_id;
END$$


/*
	Exercise 4:
    Create a function named count_trainings that takes
    as input a department name and returns the total
    of trainings assigned to all its employees.
*/
DROP FUNCTION IF EXISTS count_trainings$$
CREATE FUNCTION count_trainings (
	input_department_name VARCHAR(30))
	RETURNS INT
	READS SQL DATA
BEGIN
	DECLARE total_trainings INT;

	SET total_trainings = (SELECT COUNT(ET.training_id)
						   FROM department AS D
						   INNER JOIN employee AS E ON D.department_code = E.department_code
						   INNER JOIN employee_training AS ET ON E.employee_code = ET.employee_code
						   WHERE D.name = input_department_name);

	RETURN total_trainings;
END$$


/*
	Exercise 5:
    Create a function named closest_hire that takes
    a date as input and returns the employee code
    of the employee that was hired the closest to that date.
    If no employee was hired after the input date
    the function must return NULL.
*/
DROP FUNCTION IF EXISTS closest_hire$$
CREATE FUNCTION closest_hire (
	input_date DATE)
	RETURNS CHAR(5)
	READS SQL DATA
BEGIN
	DECLARE closest_employee_code CHAR(5);

	-- First employee hired strictly after input_date (a hire ON input_date is not counted).
	-- If no row matches, the subquery yields NULL, so the function returns NULL.
	SET closest_employee_code = (SELECT employee_code FROM employee
								 WHERE hire_date > input_date
								 ORDER BY hire_date ASC, employee_code ASC
								 LIMIT 1);

	RETURN closest_employee_code;
END$$

DELIMITER ;
