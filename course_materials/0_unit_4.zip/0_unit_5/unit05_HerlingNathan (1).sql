/* 
	Exercise 1: 
    Create a database called `business` if it does not exist.
*/
CREATE DATABASE IF NOT EXISTS business;


/*
	Exercise 2: 
    Create the `department` table in the `business` database
	based on the Physical Data Model provided in business_pdm.png.
*/
CREATE TABLE IF NOT EXISTS business.department (
	department_code CHAR(5) NOT NULL,
	name VARCHAR(30) NOT NULL,
	CONSTRAINT pk_department PRIMARY KEY (department_code)
);


/*
	Exercise 3:
    Create the `employee` table in the `business` database 
    based on the Physical Data Model provided in business_pdm.png. 
*/
CREATE TABLE IF NOT EXISTS business.employee (
	employee_code CHAR(5) NOT NULL,
	first_name VARCHAR(20) NOT NULL,
	last_name VARCHAR(20) NOT NULL,
	address VARCHAR(50),
	phone_number CHAR(14),
	hire_date DATE NOT NULL,
	department_code CHAR(5),
	CONSTRAINT pk_employee PRIMARY KEY (employee_code),
	INDEX fk_employee_department_idx (department_code),
	CONSTRAINT fk_employee_department FOREIGN KEY (department_code)
		REFERENCES business.department (department_code)
);



/*
	Exercise 4:
    Create the `training` table in the `business` database 
	based on the Physical Data Model provided in business_pdm.png.
*/
CREATE TABLE IF NOT EXISTS business.training (
	training_id INT NOT NULL,
	name VARCHAR(50) NOT NULL,
	CONSTRAINT pk_training PRIMARY KEY (training_id)
);


/*
	Exercise 5:
    Create the `employee_training` table in the `business` database
	based on the Physical Data Model provided in business_pdm.png.
    If a row of a parent table is deleted, the corresponding records
    in the `employee_training` table should be automatically deleted.
*/
CREATE TABLE IF NOT EXISTS business.employee_training (
	employee_code CHAR(5) NOT NULL,
	training_id INT NOT NULL,
	CONSTRAINT pk_employee_training PRIMARY KEY (employee_code, training_id),
	INDEX fk_employee_training_training_idx (training_id),
	CONSTRAINT fk_employee_training_employee FOREIGN KEY (employee_code)
		REFERENCES business.employee (employee_code)
		ON DELETE CASCADE,
	CONSTRAINT fk_employee_training_training FOREIGN KEY (training_id)
		REFERENCES business.training (training_id)
		ON DELETE CASCADE
);


/*
	Exercise 6:
    Write a single query to insert into the `department` table the complete set of data 
    provided in business_data.xlsx for that table.
*/
INSERT INTO business.department (department_code, name) VALUES
	('d001', 'Research & Development'),
	('d002', 'Production'),
	('d003', 'IT Support'),
	('d004', 'Operations'),
	('d005', 'Customer Service'),
	('d006', 'Purchasing'),
	('d007', 'Sales and Marketing'),
	('d008', 'Human Resource Management'),
	('d009', 'Accounting and Finance'),
	('d010', 'Legal Deparment');


/*
	Exercise 7:
    Write a single query to insert into the `employee` table the complete set of data 
    provided in business_data.xlsx for that table.
*/
    INSERT INTO business.employee
	(employee_code, first_name, last_name, phone_number, address, hire_date, department_code)
VALUES
	('e001', 'Andy',  'Wong',   '(603) 555-6880', '345 South Street',    '2001-01-15', 'd002'),
	('e002', 'John',  'Wilson', '(518) 555-6690', '560 Broadway',        '2017-03-19', 'd001'),
	('e003', 'Mike',  'Taylor', '(480) 532-6567', '5212 Saint Croix Ct', '2003-11-14', NULL),
	('e004', 'Vivek', 'Pandey', '(603) 555-4420', '15 Mineral Drive',    '2003-11-15', 'd003'),
	('e005', 'Nola',  'Davis',  '(478) 555-8822', '15 Long Ave',         '2016-03-23', 'd007'),
	('e006', 'Kathy', 'Cooper', '(212) 555-9630', '15 Hatter Drive',     '2011-11-18', 'd008'),
	('e007', 'Tom',   'Harper', '(212) 555-7755', '64 Highland Street',  '2010-04-11', 'd009');


/*
	Exercise 8:
    Write a query to make NULL the address for all the employees.
*/
UPDATE business.employee
SET address = NULL;



/*
	Exercise 9:
    Write a query to modify the phone number to '(XXX) XXX-XXXX' 
    for all the employees hired in 2003-11-15.
*/
UPDATE business.employee
SET phone_number = '(XXX) XXX-XXXX'
WHERE hire_date = '2003-11-15';


/*
	Exercise 10:
    Write a query to delete the employees with that do not belong
    to any department.
*/
DELETE FROM business.employee
WHERE department_code IS NULL;
