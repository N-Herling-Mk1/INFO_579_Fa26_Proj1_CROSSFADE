CROSSFADE - tests for database_implementation.sql (INFO 579 Project 2, Task 1)

  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  $env:CROSSFADE_DB_PASSWORD = "your-root-password"
  .venv\Scripts\python -m pytest

The tests DROP and rebuild the `crossfade` database from database_implementation.sql (twice) and leave it loaded.
Full guide, coverage and what the tests could miss: test_implementation_guide.pdf.
