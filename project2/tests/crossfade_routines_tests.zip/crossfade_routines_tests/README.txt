CROSSFADE - tests for routines.sql (INFO 579 Project 2, Task 4)

  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  $env:CROSSFADE_DB_PASSWORD = "your-root-password"
  .venv\Scripts\python -m pytest --fresh

--fresh rebuilds the `crossfade` database from database_implementation.sql first; the tests then run routines.sql
and call each routine; every write is rolled back.
Full guide, coverage and what the tests could miss: test_routines_guide.pdf.
