CROSSFADE - tests for routines.sql (INFO 579 Project 2, Task 4)

  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  $env:CROSSFADE_DB_PASSWORD = "your-root-password"
  .venv\Scripts\python -m pytest --fresh

--fresh rebuilds the `crossfade` database from database_implementation.sql first; the tests then run routines.sql
and call each routine; every write is rolled back. routines_example_usage.sql (example usage, not a
deliverable) is run too; without it, that one test is skipped.
Full guide, coverage and what the tests could miss: test_routines_guide.pdf.

Also here: rubric_routines.md, every condition of the brief that applies to routines.sql, quoted word for word and
checked against the last test run; and use_case_reference.pdf, every use case with each query's input,
expected output and test cases.
