# CROSSFADE Project 2: single_table.sql starter kit

Everything needed to write `single_table.sql` and test it, except the SQL itself.

| File | What it is |
|---|---|
| `single_table.sql` | **the file you write.** Every comment is kept: each says which use case the query answers, the business need behind it, the question, the requirements (a)-(e) it must meet and the output columns. Write the statement under each comment. |
| `database_implementation.sql` | builds the `crossfade` database with the Project 1 sample data (401 rows) |
| `data.csv` | the Project 1 sample data; the tests compute the expected answers from it |
| `use_cases.json` | the use cases the comments refer to (UC-01 ... UC-15) |
| `conftest.py`, `oracle.py`, `test_single_table.py`, `pytest.ini`, `requirements.txt` | the tests |
| `README.md` | how the tests work, and the table of what must match between the `.sql` and the tests |
| `run_tests_locally.pdf` | every step to run the tests on your machine, and what each failure means |
| `use_case_reference.pdf` | every use case: the tables and columns it reads, each query's input and expected output, every test case |

## Steps

1. `pip install -r requirements.txt` (a venv is a good idea: `python -m venv .venv`, then `.venv\Scripts\python -m pip ...`)
2. Build the database: run `database_implementation.sql` in Workbench (open, Execute), or let the tests do it with `--fresh`.
3. PowerShell: `$env:CROSSFADE_DB_PASSWORD = "your-root-password"` then `python -m pytest --fresh` once, `python -m pytest` after.
4. Write a query under its comment, rerun, repeat. With nothing written the per-query tests are skipped and the
   coverage and behaviour tests fail, each naming what is missing; the target is 66 passed.

## Rules the comments fix

- `Output:` is the contract for your column names and their order (`AS payee`, ...). The expected rows come from `oracle.py`.
- `Requirements:` must list exactly the (a)-(e) features your SQL uses: (a) single-row function, (b) aggregate,
  (c) `ORDER BY`, (d) `LIMIT n`, (e) `CASE` or `IF`. If you meet them differently, change the line to match.
- Read only the columns your use cases list in `use_cases.json`, and only the one table named after the tag.
- Every day count is measured to the fixed report date `'2026-09-30'`, not `CURDATE()`.
- `[E1]` is **EXPECTED TO FAIL**: a write MySQL must refuse with error 1062. It stays last, because an error stops a
  script run.
