# CROSSFADE Project 2: starter kit for single_table.sql and multiple_table.sql

Everything needed to write `single_table.sql` (Task 2) and `multiple_table.sql` (Task 3) and test them, except
the SQL itself.

| File | What it is |
|---|---|
| `single_table.sql` | **a file you write (Task 2).** Every comment is kept: each says which use case the query answers, the business need behind it, the question, the requirements (a)-(e) it must meet and the output columns. Write the statement under each comment. |
| `multiple_table.sql` | **a file you write (Task 3).** Same idea; each comment also names the Task 3 requirement (3.1-3.5), the tables to join and what one result row is. |
| `database_implementation.sql` | builds the `crossfade` database with the Project 1 sample data (401 rows) |
| `data.csv` | the Project 1 sample data; the tests compute the expected answers from it |
| `use_cases.json` | the use cases the comments refer to (UC-01 ... UC-15) |
| `conftest.py`, `oracle.py`, `oracle_multiple.py`, `test_single_table.py`, `test_multiple_table.py`, `test_implementation.py`, `pytest.ini`, `requirements.txt` | the tests |
| `README.md` | how the tests work, and the table of what must match between the `.sql` and the tests |
| `run_tests_locally.pdf` | every step to run the tests on your machine, and what each failure means |
| `use_case_reference.pdf` | every use case: the tables and columns it reads, each query's input and expected output, every test case |
| `test_*_guide.pdf` | one per test file: what it checks, what it could miss, how to run it |

## Steps

1. `pip install -r requirements.txt` (a venv is a good idea: `python -m venv .venv`, then `.venv\Scripts\python -m pip ...`)
2. Build the database: run `database_implementation.sql` in Workbench (open, Execute), or let the tests do it with `--fresh`.
3. PowerShell: `$env:CROSSFADE_DB_PASSWORD = "your-root-password"`, then one file at a time:
   `python -m pytest test_single_table.py` (target 71 passed) and `python -m pytest test_multiple_table.py`
   (target 80 passed). Add `--fresh` once to rebuild the database first.
4. Write a query under its comment, rerun, repeat. With nothing written the per-query tests are skipped and the
   coverage and behaviour tests fail, each naming what is missing.

## Rules the comments fix

- `Output:` is the contract for your column names and their order (`AS usd_per_1000_streams`, ...). The expected rows come from `oracle.py`.
- The first line of `Requirements:` must list exactly the (a)-(e) features your SQL uses (the indented lines
  under it quote the brief and are not read by the tests): (a) single-row function, (b) aggregate,
  (c) `ORDER BY`, (d) `LIMIT n`, (e) `CASE` or `IF`. If you meet them differently, change the line to match.
- Read only the columns your use cases list in `use_cases.json`, and only the one table named after the tag.
- Every day count is measured to the fixed report date `'2026-09-30'`, not `CURDATE()`.
- `[E1]` is a write MySQL must refuse with error 1062. Write it inside the block comment under its comment, ending with
  `;`, so it stays **DISABLED**: a script run skips it and the file runs clean, while the tests still run it on its own.
  Never type the two characters `*` `/` together inside that block: they would close the comment early.
- multiple_table.sql: `Requirements: 3.x` must be met by the SQL itself (3.1 an associative table INNER JOINed to the
  two tables it relates, 3.2 `LEFT OUTER JOIN`, 3.3 `UNION`/`INTERSECT`/`EXCEPT`, 3.4 `IN`/`ANY`/`ALL`/`EXISTS (SELECT ...)`,
  3.5 starts with `WITH`). Name every join in full (`INNER JOIN`, `LEFT OUTER JOIN`); no bare `JOIN`, no comma joins.
  `Tables:` must equal the tables MySQL's plan reads, and the columns read must equal the use cases' `multipleColumns`.
