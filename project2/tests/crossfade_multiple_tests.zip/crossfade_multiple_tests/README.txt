CROSSFADE - tests for multiple_table.sql (INFO 579 Project 2, Task 3)

  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  $env:CROSSFADE_DB_PASSWORD = "your-root-password"
  .venv\Scripts\python -m pytest --fresh

--fresh rebuilds the `crossfade` database from database_implementation.sql first; every write a test makes is rolled back.
Full guide, coverage and what the tests could miss: test_multiple_table_guide.pdf.

Also here: rubric_multiple_table.md, every condition of the brief that applies to multiple_table.sql, quoted word for word and
checked against the last test run; and use_case_reference.pdf, every use case with each query's input,
expected output and test cases.
